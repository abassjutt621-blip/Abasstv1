require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const admin = require('firebase-admin');

const app = express();
const PORT = Number(process.env.PORT || 10000);

app.set('trust proxy', 1);
app.use(helmet({ crossOriginResourcePolicy: false }));
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true, limit: '2mb' }));
app.use(morgan('combined'));

const origins = String(process.env.CORS_ORIGINS || '*').split(',').map(s => s.trim()).filter(Boolean);
app.use(cors({
  origin: (origin, cb) => {
    if (!origin || origins.includes('*') || origins.includes(origin)) return cb(null, true);
    return cb(new Error('CORS origin not allowed'));
  },
  methods: ['GET','POST','PUT','PATCH','DELETE','OPTIONS'],
  allowedHeaders: ['Content-Type','Authorization','X-API-Key']
}));

function initFirebase() {
  if (admin.apps.length) return admin.database();
  const privateKey = String(process.env.FIREBASE_PRIVATE_KEY || '').replace(/\\n/g, '\n');
  const hasServiceAccount = process.env.FIREBASE_PROJECT_ID && process.env.FIREBASE_CLIENT_EMAIL && privateKey;
  if (!hasServiceAccount || !process.env.FIREBASE_DATABASE_URL) {
    console.warn('Firebase Admin is not configured. Set FIREBASE_DATABASE_URL, FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL and FIREBASE_PRIVATE_KEY.');
    return null;
  }
  admin.initializeApp({
    credential: admin.credential.cert({
      projectId: process.env.FIREBASE_PROJECT_ID,
      clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
      privateKey
    }),
    databaseURL: process.env.FIREBASE_DATABASE_URL
  });
  return admin.database();
}

const db = initFirebase();

function requireDb(req, res, next) {
  if (!db) return res.status(503).json({ ok:false, error:'Firebase is not configured on the server.' });
  next();
}

function requireApiKey(req, res, next) {
  const configured = String(process.env.ADMIN_API_KEY || '').trim();
  if (!configured) return next();
  const supplied = req.get('X-API-Key') || (req.get('Authorization') || '').replace(/^Bearer\s+/i, '');
  if (supplied !== configured) return res.status(401).json({ ok:false, error:'Invalid API key.' });
  next();
}

app.get('/health', (req,res) => res.json({
  ok:true,
  service:'ABASS TV Node.js API',
  node:process.version,
  environment:process.env.NODE_ENV || 'development',
  firebase:!!db,
  time:new Date().toISOString()
}));

app.get('/api', requireApiKey, (req,res) => res.json({
  ok:true,
  name:'ABASS TV API',
  version:'1.0.0',
  endpoints:['/api/channels','/api/movies','/api/users','/api/settings','/api/content']
}));

const SAFE_COLLECTIONS = new Set([
  'abass_content/channels',
  'abass_content/movies',
  'abass_content/videos',
  'abass_content/slider',
  'abass_content/ad',
  'abass_settings',
  'abass_profiles',
  'abass_profile_change_requests',
  'abass_users',
  'abass_rewards',
  'abass_withdrawals'
]);

function cleanPath(value) {
  return String(value || '').replace(/^\/+|\/+$/g, '').replace(/\/+/g,'/');
}
function assertSafePath(path) {
  const p = cleanPath(path);
  if (!SAFE_COLLECTIONS.has(p)) throw Object.assign(new Error('Path is not allowlisted.'), { status:403 });
  return p;
}
function stripSensitiveUser(v) {
  if (!v || typeof v !== 'object') return v;
  const x = { ...v };
  delete x.password;
  delete x.pass;
  delete x.passwordHash;
  delete x.token;
  delete x.refreshToken;
  return x;
}

async function collectionList(path, sanitize=false) {
  const snap = await db.ref(path).once('value');
  const val = snap.val() || {};
  if (!val || typeof val !== 'object') return {};
  if (!sanitize) return val;
  return Object.fromEntries(Object.entries(val).map(([k,v]) => [k, stripSensitiveUser(v)]));
}

function collectionRouter(collectionPath, sanitize=false) {
  const router = express.Router();
  router.get('/', async (req,res,next) => {
    try { res.json({ ok:true, data: await collectionList(collectionPath, sanitize) }); } catch(e) { next(e); }
  });
  router.get('/:id', async (req,res,next) => {
    try {
      const snap = await db.ref(`${collectionPath}/${encodeURIComponent(req.params.id)}`).once('value');
      const val = snap.val();
      if (val == null) return res.status(404).json({ok:false,error:'Record not found'});
      res.json({ok:true,data:sanitize?stripSensitiveUser(val):val});
    } catch(e) { next(e); }
  });
  router.post('/', async (req,res,next) => {
    try {
      const ref = db.ref(collectionPath).push();
      const payload = { ...(req.body || {}), createdAt: Date.now(), updatedAt: Date.now() };
      await ref.set(payload);
      res.status(201).json({ok:true,id:ref.key,data:payload});
    } catch(e) { next(e); }
  });
  router.put('/:id', async (req,res,next) => {
    try {
      const id = encodeURIComponent(req.params.id);
      const payload = { ...(req.body || {}), updatedAt: Date.now() };
      await db.ref(`${collectionPath}/${id}`).update(payload);
      const snap = await db.ref(`${collectionPath}/${id}`).once('value');
      const val = snap.val();
      res.json({ok:true,id:req.params.id,data:sanitize?stripSensitiveUser(val):val});
    } catch(e) { next(e); }
  });
  router.delete('/:id', async (req,res,next) => {
    try {
      await db.ref(`${collectionPath}/${encodeURIComponent(req.params.id)}`).remove();
      res.json({ok:true,deleted:req.params.id});
    } catch(e) { next(e); }
  });
  return router;
}

app.use('/api/channels', requireApiKey, requireDb, collectionRouter('abass_content/channels'));
app.use('/api/movies', requireApiKey, requireDb, collectionRouter('abass_content/movies'));
app.use('/api/users', requireApiKey, requireDb, collectionRouter('abass_users', true));

app.get('/api/content', requireApiKey, requireDb, async (req,res,next) => {
  try {
    const [channels,movies,slider,ad] = await Promise.all([
      collectionList('abass_content/channels'),
      collectionList('abass_content/movies'),
      collectionList('abass_content/slider'),
      collectionList('abass_content/ad')
    ]);
    res.json({ok:true,data:{channels,movies,slider,ad}});
  } catch(e){next(e);}
});

app.get('/api/settings', requireApiKey, requireDb, async (req,res,next) => {
  try { res.json({ok:true,data:await collectionList('abass_settings')}); } catch(e){next(e);}
});
app.put('/api/settings/:key', requireApiKey, requireDb, async (req,res,next) => {
  try {
    const key=cleanPath(req.params.key);
    if (!key || key.includes('..')) return res.status(400).json({ok:false,error:'Invalid setting key'});
    await db.ref(`abass_settings/${key}`).set(req.body);
    res.json({ok:true,path:`abass_settings/${key}`,data:req.body});
  } catch(e){next(e);}
});

app.get('/api/firebase/path', requireApiKey, requireDb, async (req,res,next) => {
  try {
    const path=assertSafePath(req.query.path);
    const snap=await db.ref(path).once('value');
    res.json({ok:true,path,data:snap.val()});
  } catch(e){next(e);}
});
app.put('/api/firebase/path', requireApiKey, requireDb, async (req,res,next) => {
  try {
    const path=assertSafePath(req.body.path);
    await db.ref(path).set(req.body.data ?? null);
    res.json({ok:true,path,data:req.body.data ?? null});
  } catch(e){next(e);}
});

app.get('/api/config/public', requireDb, async (req,res,next) => {
  try {
    const [channels,movies,settings] = await Promise.all([
      collectionList('abass_content/channels'),
      collectionList('abass_content/movies'),
      collectionList('abass_settings')
    ]);
    res.json({ok:true,data:{channels,movies,settings}});
  } catch(e){next(e);}
});

app.use((req,res)=>res.status(404).json({ok:false,error:'Route not found'}));
app.use((err,req,res,next)=>{
  console.error(err);
  const status=Number(err.status)||500;
  res.status(status).json({ok:false,error: status===500 ? 'Server error' : err.message});
});

app.listen(PORT,'0.0.0.0',()=>console.log(`ABASS TV API listening on 0.0.0.0:${PORT}`));
