# ABASS TV — Node.js Backend for Render

This is a deployable Express API designed to sit between the ABASS TV Admin/User panels and Firebase Realtime Database.

## What it includes

- `/health` health check
- Firebase Admin SDK connection
- CORS + Helmet + request logging
- Optional `X-API-Key` protection for Admin API routes
- Channel CRUD: `/api/channels`
- Movie CRUD: `/api/movies`
- User listing/CRUD with sensitive password fields stripped from API responses
- Settings: `/api/settings`
- Combined content: `/api/content`
- Allowlisted Firebase browser: `/api/firebase/path`
- Public read-only app config: `/api/config/public`
- Render `render.yaml`
- Node version pin

## Firebase setup

Create/download a Firebase Admin SDK service account and put its values in Render Environment Variables. Never place the service-account private key inside an HTML file or Git repository.

Required:

- `FIREBASE_DATABASE_URL`
- `FIREBASE_PROJECT_ID`
- `FIREBASE_CLIENT_EMAIL`
- `FIREBASE_PRIVATE_KEY`

Recommended:

- `ADMIN_API_KEY`
- `CORS_ORIGINS`

## Render deployment

1. Put this folder in a GitHub repository.
2. In Render choose **New → Web Service** and connect the repository, or use the included `render.yaml` Blueprint.
3. Runtime: Node.
4. Build command: `npm install`.
5. Start command: `npm start`.
6. Add the Firebase environment variables and `ADMIN_API_KEY` in Render's Environment settings.
7. Deploy.
8. Open `https://YOUR-SERVICE.onrender.com/health`.
9. Put `https://YOUR-SERVICE.onrender.com` into the ABASS TV Admin Panel's Node.js API Base URL.

Render web services must listen on `0.0.0.0` and should use the `PORT` environment variable; this backend does that. Render documents `npm install`/`npm start` as normal Node.js build/start commands. Free web services are intended for testing/hobby use and can spin down after inactivity.

## API examples

GET `/health`

GET `/api/channels`

GET `/api/channels/CHANNEL_ID`

PUT `/api/channels/CHANNEL_ID`

POST `/api/channels`

DELETE `/api/channels/CHANNEL_ID`

GET `/api/movies`

GET `/api/settings`

PUT `/api/settings/nodeApi`

GET `/api/content`

GET `/api/config/public`

For protected endpoints send:

`X-API-Key: YOUR_ADMIN_API_KEY`

## Important

This backend does not replace your existing Firebase data. It uses Firebase as the shared source of truth so the existing User Panel can continue reading the same paths. Your Admin Panel can gradually switch from direct Firebase writes to these API routes.
